#include <iostream>
#include <vector>
#include <queue>
#include <map>
#include <string>
#include <algorithm>
#include <cctype>

using namespace std;

struct Step {
    vector<int> state;
    string action;
};

bool checkGoal(const vector<int>& currentState, const vector<int>& targetState) {
    for (size_t i = 0; i < currentState.size(); i++) {
        if (targetState[i] != -1 && currentState[i] != targetState[i]) {
            return false;
        }
    }
    return true;
}

bool isNumber(const string& s) {
    if (s.empty()) return false;
    for (char const &c : s) {
        if (!isdigit(c)) return false;
    }
    return true;
}

int main() {
    string inputStr;
    int n;
    
    cout << "=== N-JUG WATER POURING PROBLEM (BFS) ===\n";
    
    while (true) {
        cout << "Nhap so luong binh: ";
        cin >> inputStr;
        if (isNumber(inputStr)) {
            n = stoi(inputStr);
            if (n > 0) break;
        }
        cout << "vui lo\u0007ng nh\u0001p gia\u001B tri\u001B la\u0000 so\u0005\n";
    }

    vector<int> capacities(n);
    for (int i = 0; i < n; i++) {
        while (true) {
            cout << "Dung tich toi da cua binh " << i + 1 << ": ";
            cin >> inputStr;
            if (isNumber(inputStr)) {
                capacities[i] = stoi(inputStr);
                break;
            }
            cout << "vui lo\u0007ng nh\u0001p gia\u001B tri\u001B la\u0000 so\u0005\n";
        }
    }

    vector<int> target(n);
    cout << "\nNhap trang thai dich mong muon (Nhap so hoac 'x' neu la bat ky):\n";
    for (int i = 0; i < n; i++) {
        while (true) {
            cout << "Binh " << i + 1 << ": ";
            cin >> inputStr;
            if (inputStr == "x" || inputStr == "X") {
                target[i] = -1;
                break;
            } else if (isNumber(inputStr)) {
                target[i] = stoi(inputStr);
                break;
            }
            cout << "vui lo\u0007ng nh\u0001p gia\u001B tri\u001B la\u0000 so\u0005\n";
        }
    }

    vector<int> startState(n, 0);
    queue<vector<int> > q;
    map<vector<int>, pair<vector<int>, string> > parent;

    q.push(startState);
    bool found = false;
    vector<int> finalState;

    if (checkGoal(startState, target)) {
        found = true;
        finalState = startState;
    }

    while (!q.empty() && !found) {
        vector<int> u = q.front();
        q.pop();

        for (int i = 0; i < n; i++) {
            if (u[i] < capacities[i]) {
                vector<int> v = u;
                v[i] = capacities[i];
                if (v != startState && parent.count(v) == 0) {
                    parent[v] = make_pair(u, "Do day nuoc vao binh " + to_string(i + 1));
                    if (checkGoal(v, target)) { found = true; finalState = v; break; }
                    q.push(v);
                }
            }
        }
        if (found) break;

        for (int i = 0; i < n; i++) {
            if (u[i] > 0) {
                vector<int> v = u;
                v[i] = 0;
                if (v != startState && parent.count(v) == 0) {
                    parent[v] = make_pair(u, "Do het nuoc trong binh " + to_string(i + 1) + " ra ngoai");
                    if (checkGoal(v, target)) { found = true; finalState = v; break; }
                    q.push(v);
                }
            }
        }
        if (found) break;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i != j && u[i] > 0 && u[j] < capacities[j]) {
                    vector<int> v = u;
                    int pourAmount = min(u[i], capacities[j] - u[j]);
                    
                    v[i] -= pourAmount;
                    v[j] += pourAmount;

                    if (v != startState && parent.count(v) == 0) {
                        parent[v] = make_pair(u, "Do nuoc tu binh " + to_string(i + 1) + " sang binh " + to_string(j + 1));
                        if (checkGoal(v, target)) { found = true; finalState = v; break; }
                        q.push(v);
                    }
                }
            }
        }
    }

    if (found) {
        cout << "\n========================================\n";
        cout << "       TIM THAY LOI GIAI NGAN NHAT!      \n";
        cout << "========================================\n";
        
        vector<Step> path;
        vector<int> curr = finalState;

        while (curr != startState) {
            Step s;
            s.state = curr;
            s.action = parent[curr].second;
            path.push_back(s);
            curr = parent[curr].first;
        }

        cout << "Trang thai bat dau: [";
        for (int i = 0; i < n; i++) cout << startState[i] << (i == n - 1 ? "" : ", ");
        cout << "]\n";

        for (int i = path.size() - 1; i >= 0; i--) {
            cout << " -> Hanh dong: " << path[i].action << " => Khay binh: [";
            for (int j = 0; j < n; j++) {
                cout << path[i].state[j] << (j == n - 1 ? "" : ", ");
            }
            cout << "]\n";
        }
    } else {
        cout << "\nkhong the di den trang thai cuoi duoc tu trang thai ban dau ban da cho\n";
    }

    return 0;
}
